/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=10x20 player player.png 
 * Time-stamp: Wednesday 04/03/2024, 18:35:15
 * 
 * Image Information
 * -----------------
 * player.png 10@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PLAYER_H
#define PLAYER_H

extern const unsigned short player[200];
#define PLAYER_SIZE 400
#define PLAYER_LENGTH 200
#define PLAYER_WIDTH 10
#define PLAYER_HEIGHT 20

#endif

