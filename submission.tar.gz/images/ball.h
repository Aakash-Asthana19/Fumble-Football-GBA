/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=20x10 ball Ball.png 
 * Time-stamp: Wednesday 04/03/2024, 18:35:35
 * 
 * Image Information
 * -----------------
 * Ball.png 20@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BALL_H
#define BALL_H

extern const unsigned short Ball[200];
#define BALL_SIZE 400
#define BALL_LENGTH 200
#define BALL_WIDTH 20
#define BALL_HEIGHT 10

#endif

