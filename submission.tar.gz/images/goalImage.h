/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=20x40 goalImage goalImage.PNG 
 * Time-stamp: Thursday 04/04/2024, 17:45:32
 * 
 * Image Information
 * -----------------
 * goalImage.PNG 20@40
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GOALIMAGE_H
#define GOALIMAGE_H

extern const unsigned short goalImage[800];
#define GOALIMAGE_SIZE 1600
#define GOALIMAGE_LENGTH 800
#define GOALIMAGE_WIDTH 20
#define GOALIMAGE_HEIGHT 40

#endif

