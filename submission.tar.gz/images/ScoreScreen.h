/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 ScoreScreen SCORE SCREEN.png 
 * Time-stamp: Thursday 04/04/2024, 19:13:01
 * 
 * Image Information
 * -----------------
 * SCORE SCREEN.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SCORESCREEN_H
#define SCORESCREEN_H

extern const unsigned short SCORESCREEN[38400];
#define SCORESCREEN_SIZE 76800
#define SCORESCREEN_LENGTH 38400
#define SCORESCREEN_WIDTH 240
#define SCORESCREEN_HEIGHT 160

#endif

