*The game I created is where you must control a football player to recover the fumbled trophy.
*Use the arrow keys to navigate your player to the trophy within 15 seconds.
*Make sure to reach the trophy in time and not go out of bounds to avoid losing.
*Reach the trophy in time while staying in bounds to win and compare your time to your fastest one.
*Press backspace to navigate to the start screen and press enter to propogate to the next screen when
your currently on the start screen or win screen.

Have Fun!